package test2;

public class Robot {

}
