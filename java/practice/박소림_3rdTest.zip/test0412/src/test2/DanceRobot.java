package test2;

public class DanceRobot extends Robot {
	void dance() {
		//1. "춤을 춥니다 ."를 출력한다.
		//(소프트웨어 공학기술의 요구사항 도출 기법을 활용하여 업무 분석가가 제시한 분석모델에 대해서 확인할 수 있다.10)
		System.out.println("춤을 춥니다.");
	}
}
