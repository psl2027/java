package test2;

public class DrawRobot extends Robot {
	void draw() {
		//2."그림을 그립니다." 를 출력한다.
		//(업무 분석가가 제시한 분석모델이 개발할 응용소프트웨어에 미칠 영향을 검토하여 기술적인 타당성 조사를 할 수 있다.10)
		System.out.println("그림을 그립니다 .");
	}
}
