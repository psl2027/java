package array;

public class Main02 {

	public static void main(String[] args) {
		int a = 4/3;
		System.out.println("a : " + a);
		
		float b = 4/3;
		System.out.println("b : " + b);
//		
		float c = (float)(4/3);
		System.out.println("c : " + c);
		
		float e = (float)4/(float)3;
		System.out.println("e : " + e);
//		
		float d = 4.0f/3.0f;
		System.out.println("d : " + d);
		
		
		System.out.println("---------------");
		
	}

}
